import { Users as UsersIcon, LogOut, Trash2 } from "lucide-react";
import { useGroupStore } from "../store/useGroupStore";
import { useChatStore } from "../store/useChatStore";

export default function GroupCard({
  group,
  currentUserId,
  onOpen,
  onShowMembers,
  onLeaveOrDelete,
}) {
  const { setSelectedUser } = useChatStore();
  const { setSelectedGroup } = useGroupStore();

  const isOwner = group?.createdBy === currentUserId;

  const handleOpen = () => {
    if (!group) return;
    onOpen?.(group);
    setSelectedGroup(group);
    setSelectedUser(null);
  };

  const handleMembers = (e) => {
    e.stopPropagation();
    if (!group?._id) return;
    onShowMembers?.(group._id);
  };

  const handleLeaveOrDelete = (e) => {
    e.stopPropagation();
    if (!group?._id) return;
    onLeaveOrDelete?.(group._id, { isOwner });
  };

  return (
    <div
      onClick={handleOpen}
      className={`flex-shrink-0 w-65 snap-start flex flex-col justify-between p-3 rounded-xl border cursor-pointer transition
        ${
          isOwner
            ? "bg-red-50 border-red-200 hover:border-red-300"
            : "bg-emerald-50 border-emerald-200 hover:border-emerald-300"
        }`}
    >
      <div className="min-w-0 mb-3">
        <div className="font-medium truncate">{group.name}</div>
        <div className="text-xs text-neutral-600">
          {group.members?.length ?? 0} member
          {(group.members?.length ?? 0) === 1 ? "" : "s"}
        </div>
      </div>

      <div className="flex items-center justify-between">
        <button
          onClick={handleMembers}
          className="px-2 py-1 rounded-lg border text-xs hover:bg-neutral-100"
          title="Show members"
        >
          <UsersIcon className="inline w-4 h-4 mr-1" />
          Members
        </button>

        <button
          onClick={handleLeaveOrDelete}
          className={`px-2 py-1 rounded-lg text-xs text-white ${
            isOwner
              ? "bg-red-600 hover:bg-red-700"
              : "bg-orange-500 hover:bg-orange-600"
          }`}
          title={isOwner ? "Delete group" : "Leave group"}
        >
          {isOwner ? (
            <>
              <Trash2 className="inline w-4 h-4 mr-1" />
              Delete
            </>
          ) : (
            <>
              <LogOut className="inline w-4 h-4 mr-1" />
              Leave
            </>
          )}
        </button>
      </div>
    </div>
  );
}
