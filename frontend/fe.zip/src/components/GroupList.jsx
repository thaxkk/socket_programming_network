import { useEffect, useMemo } from "react";
import { useGroupStore } from "../store/useGroupStore";
import { useChatStore } from "../store/useChatStore";

import UsersLoadingSkeleton from "./UsersLoadingSkeleton";
import NoChatsFound from "./NoChatsFound";
import GroupCard from "./GroupCard";
import MembersModal from "./MemberModal";

function GroupList() {
  const {
    getAllGroups,
    allGroups,
    currentMembers,
    currentMemberCount,
    isAllGroupsLoading,
    leaveGroup,
    deleteGroup,
    setSelectedGroup,
    getGroupMembers,
  } = useGroupStore();
  const { setSelectedUser } = useChatStore();

  const currentUserId = useMemo(
    () => String(useChatStore.getState()?.authUser?._id || ""),
    []
  );

  useEffect(() => {
    getAllGroups();
  }, [getAllGroups]);

  if (isAllGroupsLoading) return <UsersLoadingSkeleton />;
  if (!allGroups || allGroups.length === 0)
    return <NoChatsFound message="No groups found" />;

  const isJoined = (group) => {
    const members = group?.members || [];
    return members.some((m) => String(m?._id ?? m) === currentUserId);
  };

  const handleOpen = (group) => {
    setSelectedUser(null);
    setSelectedGroup(group);
  };

  const handleShowMembers = (groupId) => {
    getGroupMembers(groupId);
    const ev = new CustomEvent("open-members-modal");
    window.dispatchEvent(ev);
  };

  const handleLeaveOrDelete = async (groupId, { isOwner }) => {
    try {
      if (isOwner && typeof deleteGroup === "function") {
        await deleteGroup(groupId);
      } else if (typeof leaveGroup === "function") {
        await leaveGroup(groupId);
      } else {
        console.warn("leaveGroup/deleteGroup not implemented");
      }
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <>
      <div className="space-y-3">
        {allGroups.map((group) => (
          <GroupCard
            key={group._id}
            group={group}
            currentUserId={currentUserId}
            onOpen={handleOpen}
            onShowMembers={handleShowMembers}
            onLeaveOrDelete={handleLeaveOrDelete}
          />
        ))}
      </div>
      <MembersModal members={currentMembers} count={currentMemberCount} />
    </>
  );
}

export default GroupList;
